<?php
session_start();
if (!isset($_SESSION['loggedin'])) {
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
 
    $conn = new mysqli('localhost', 'root', '', 'eticaret1');
    if ($conn->connect_error) {
        die("Bağlantı hatası: " . $conn->connect_error);
    }

    $product_name = $_POST['name'];
    $product_price = $_POST['price'];
    $product_stock = $_POST['stock'];
    $product_category = $_POST['category'];
    $product_description = $_POST['description'];

    $product_image = $_FILES['image']['name'];
    $target_dir = "uploads/";  
    $target_file = $target_dir . basename($product_image);
    

  
    $stmt = $conn->prepare("INSERT INTO products (name, price, stock, category, description, image) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sdssss", $product_name, $product_price, $product_stock, $product_category, $product_description, $product_image);



    $stmt->close();
    $conn->close();
}
?>
