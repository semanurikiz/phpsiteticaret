<?php
session_start();
if (!isset($_SESSION['loggedin'])) {
    header("Location: login.php");
    exit;
}
   
?>


<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Paneli - Ana Sayfa</title>
    <link rel="stylesheet" href="styles.css">

    <script>
    const content = document.querySelector('.content');

   
    content.addEventListener('mouseenter', () => {
        document.body.style.backgroundColor = 'rgb(0, 0, 0)'; 
    });


    content.addEventListener('mouseleave', () => {
        document.body.style.backgroundColor = ''; 
    });
</script>


    <style>
 body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color: rgb(255, 255, 255);
    transition: background-color 0.5s ease; 
}

body:hover {
    background-color: rgb(0, 0, 0); 
}

.navbar {
    background-color:rgb(0, 0, 0);
    padding: 20px 40px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
}

.navbar-header img {
    width: 50px;
    height: auto;
}

.navbar h1 {
    margin-left: 15px;
    font-size: 28px;
    font-weight: 600;
    color: #fff;
    text-transform: uppercase;
}


.navbar a {
    color: #fff;
    text-decoration: none;
    font-size: 16px;
    transition: all 0.3s ease-in-out;
}

.navbar a:hover {
    color: rgb(243, 18, 18); 
    transform: translateY(-2px);
    text-shadow: 50px 50px 10px rgb(46, 0, 0); 
}
.content {
    padding: 30px;
    padding-top: 40px;
    padding-bottom: 40px;
    max-width: 1200px;
    margin: 50px auto;
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
}


.content:hover {
    background-color:rgb(0, 0, 0);  
    box-shadow: 0 5px 50px rgb(255, 0, 0); 
}
.content:hover {
    background-color:rgb(0, 0, 0);  
    transition: background-color 0.3s ease; 
}

.content:hover body {
    background-color:rgb(0, 0, 0);  
}

.dashboard {
    display: flex;
    flex-wrap: wrap;
    gap: 25px;
    justify-content: space-between;
    margin-bottom: 30px;
}
.dashboard:hover {
    background-color: #e0e0e0; 
    box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
}



.stat-box {
    background-color: #fff; 
    padding: 20px;
    margin: 10px;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); 
    transition: all 0.3s ease-in-out;
}

.stat-box:hover {
    background-color: #f0f0f0; 
    box-shadow: 0 8px 16px rgba(0, 0, 0, 0.3); 
    transform: translateY(-5px); 
}


.table-container {
    background-color: #fff; 
    padding: 20px;
    margin: 10px;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); 
    transition: all 0.3s ease-in-out;
}

.table-container:hover {
    background-color: #e9e9e9; 
    box-shadow: 0 8px 16px rgba(0, 0, 0, 0.3); 
    transform: translateY(-5px);
}


table {
    width: 100%;
    border-collapse: collapse;
}

th, td {
    padding: 10px;
    text-align: left;
    border-bottom: 1px solid #ddd;
}

th {
    background-color: #f4f4f4;
}


td {
    background-color: #fff;
    color: #333;
}

tr:nth-child(even) {
    background-color: #f9f9f9;
}

tr:hover {
    background-color: #f1f1f1;
    transform: scale(1.02);
}

.footer {
    background-color:rgb(0, 0, 0);
    color: white;
    text-align: center;
    padding: 15px;
    position: relative;
    bottom: 0;
    width: 100%;
    font-size: 14px;
}

.footer a {
    color: #f39c12;
    text-decoration: none;
    transition: color 0.3s ease;
}

.footer a:hover {
    color: #f1c40f;
}
h1 {
    font-family: 'Arial', sans-serif;
    font-size: 60px;
    color: #4CAF50;
    text-transform: uppercase;
    text-align: center;
    position: relative;
    display: inline-block;
    letter-spacing: 3px;
    background-image: linear-gradient(to right, #ff7e5f, #feb47b);
    -webkit-background-clip: text;
    background-clip: text;
    animation: colorChange 3s infinite alternate, slideIn 1s ease-out;
    transition: all 0.3s ease-in-out;
}

@keyframes colorChange {
    0% {
        color: #ff7e5f;
        transform: scale(1);
    }
    100% {
        color:rgb(48, 48, 48);
        transform: scale(1.1);
    }
}

@keyframes slideIn {
    0% {
        opacity: 0;
        transform: translateX(-100px);
    }
    100% {
        opacity: 1;
        transform: translateX(0);
    }
}

h1:hover {
    color: #fff;
    text-shadow: 4px 4px 10px rgb(255, 0, 0), -4px -4px 10px rgba(0, 0, 0, 0.4);
    transform: scale(1.1) rotate(-3deg);
}


    </style>
</head>
<body>
<div class="navbar">
    <div class="navbar-header">
        <img src="indir.png" alt="Logo">
        <h1>Çiçek Buketi</h1>
    </div>
    <a href="panel.php"><i>🏠</i> Ana Sayfa</a>
    <a href="setting.php"><i>⚙️</i> Ayarlar</a>
    <a href="products.php"><i>🛒</i> Ürün Yönetimi</a>
    <a href="logout.php"><i>🚪</i> Çıkış Yap</a>
</div>

<div class="content">
    <h1>Admin Paneli</h1>
    <p>Panel üzerinden işlemlerinizi kolayca düzenleyebilirsiniz.</p>
    
    <div class="dashboard">
        <div class="stat-box">
            <h3>Toplam Ziyaretçi</h3>
            <p>2,300 Ziyaretçi</p>
        </div>
        <div class="stat-box">
            <h3>Toplam Satış</h3>
            <p>12,000 TL</p>
        </div>
        <div class="stat-box">
            <h3>Stok Durumu</h3>
            <p>200 Ürün</p>
        </div>
        <div class="stat-box">
            <h3>Aktif Kampanyalar</h3>
            <p>5 Kampanya</p>
        </div>
    </div>

    <div class="dashboard">
        <div class="stat-box">
            <h3>Toplam Sipariş</h3>
            <p>850 Sipariş</p>
        </div>
        <div class="stat-box">
            <h3>En Popüler Ürün</h3>
            <p>Ametist Taşı</p>
        </div>
        <div class="stat-box">
            <h3>Günlük Satış</h3>
            <p>50 Ürün</p>
        </div>
        <div class="stat-box">
            <h3>Ödeme Yöntemleri</h3>
            <p>Kredi Kartı, Havale</p>
        </div>
    </div>

    <div class="table-container">
        <h2>Son Siparişler</h2>
        <table>
            <thead>
                <tr>
                    <th>Sipariş No</th>
                    <th>Müşteri</th>
                    <th>Tarih</th>
                    <th>Tutar</th>
                    <th>Durum</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>#00123</td>
                    <td>Ahmet Yılmaz</td>
                    <td>2024-12-19</td>
                    <td>350 TL</td>
                    <td>Yolda</td>
                </tr>
                <tr>
                    <td>#00124</td>
                    <td>Ayşe Demir</td>
                    <td>2024-12-18</td>
                    <td>220 TL</td>
                    <td>Teslim Edildi</td>
                </tr>
                <tr>
                    <td>#00125</td>
                    <td>Mehmet Kaya</td>
                    <td>2024-12-17</td>
                    <td>500 TL</td>
                    <td>Hazırlanıyor</td>
                </tr>
            </tbody>
        </table>
    </div>

    <div class="table-container">
        <h2>Kargo Takip</h2>
        <table>
            <thead>
                <tr>
                    <th>Sipariş No</th>
                    <th>Durum</th>
                    <th>Tarih</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>#00123</td>
                    <td>Yolda</td>
                    <td>2024-12-19</td>
                </tr>
                <tr>
                    <td>#00124</td>
                    <td>Teslim Edildi</td>
                    <td>2024-12-18</td>
                </tr>
                <tr>
                    <td>#00125</td>
                    <td>Hazırlanıyor</td>
                    <td>2024-12-17</td>
                </tr>
            </tbody>
        </table>
    </div>
</div>


    <div class="footer">
     © 2025 Tüm Hakları Saklıdır|Çiçek Buketi 
    </div>
</body>
</html>
