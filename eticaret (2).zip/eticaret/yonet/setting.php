<?php
session_start();
if (!isset($_SESSION['loggedin'])) {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Paneli - Ayarlar</title>
    <style>
      
        body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color: rgb(255, 255, 255);
    transition: background-color 0.5s ease; 
}

body:hover {
    background-color: rgb(0, 0, 0); 
}


.navbar {
    background-color: rgb(0, 0, 0);
    padding: 20px 40px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
}

.navbar-header img {
    width: 50px;
    height: auto;
}

.navbar h1 {
    margin-left: 15px;
    font-size: 28px;
    font-weight: 600;
    color: #fff;
    text-transform: uppercase;
}


.navbar a {
    color: #fff;
    text-decoration: none;
    font-size: 16px;
    transition: all 0.3s ease-in-out;
}


.navbar a:hover {
    color: rgb(243, 18, 18); 
    transform: translateY(-2px); 
    text-shadow: 50px 50px 10px rgb(46, 0, 0); 
}

.settings-container {
    max-width: 600px;
    margin: 50px auto;
    padding: 70px;
    background-color: #fff;
    border-radius: 10px;
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
    transition: background-color 0.3s ease, box-shadow 0.3s ease;
}


.settings-container:hover {
    background-color:rgb(0, 0, 0); 
    box-shadow: 0 4px 50px rgb(255, 0, 0); 
}


h2 {
    text-align: center;
    color: rgb(0, 0, 0);
}

.form-group {
    margin-bottom: 15px;
}

label {
    display: block;
    margin-bottom: 5px;
    font-weight: bold;
    color: #333;
}

input, textarea {
    width: 100%;
    padding: 10px;
    border: 1px solid #ddd;
    border-radius: 5px;
    font-size: 14px;
}

textarea {
    height: 100px;
    resize: none;
}

button.btn {
    display: block;
    width: 100%;
    padding: 10px;
    background-color: rgb(36, 64, 99);
    color: #fff;
    border: none;
    border-radius: 5px;
    font-size: 16px;
    cursor: pointer;
}

button.btn:hover {
    background-color: #5d2e70;
}


.content {
    padding: 30px;
    padding-top: 40px;
    padding-bottom: 40px;
    max-width: 1200px;
    margin: 50px auto;
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
}

.content:hover {
    background-color: rgb(0, 0, 0); 
    box-shadow: 0 5px 50px rgb(255, 0, 0); 
    transition: background-color 0.3s ease;  
}

.content:hover body {
    background-color: rgb(0, 0, 0);  
}


.dashboard {
    display: flex;
    flex-wrap: wrap;
    gap: 25px;
    justify-content: space-between;
    margin-bottom: 30px;
}

.dashboard:hover {
    background-color:rgb(0, 0, 0); 
    box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
}


.stat-box {
    background-color: #fff; 
    padding: 20px;
    margin: 10px;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    transition: all 0.3s ease-in-out;
}

.stat-box:hover {
    background-color: #f0f0f0; 
    box-shadow: 0 8px 16px rgba(0, 0, 0, 0.3); 
    transform: translateY(-5px); 
}


.table-container {
    background-color: #fff; 
    padding: 20px;
    margin: 10px;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); 
    transition: all 0.3s ease-in-out;
}

.table-container:hover {
    background-color: #e9e9e9; 
    box-shadow: 0 8px 16px rgba(0, 0, 0, 0.3); 
    transform: translateY(-5px); 
}


table {
    width: 100%;
    border-collapse: collapse;
}

th, td {
    padding: 10px;
    text-align: left;
    border-bottom: 1px solid #ddd;
}

th {
    background-color: #f4f4f4;
}

td {
    background-color: #fff;
    color: #333;
}

tr:nth-child(even) {
    background-color: #f9f9f9;
}

tr:hover {
    background-color: #f1f1f1;
    transform: scale(1.02);
}


.footer {
    background-color: rgb(0, 0, 0);
    color: white;
    text-align: center;
    padding: 15px;
    position: relative;
    bottom: 0;
    width: 100%;
    font-size: 14px;
}

.footer a {
    color: #f39c12;
    text-decoration: none;
    transition: color 0.3s ease;
}

.footer a:hover {
    color: #f1c40f;
}


h1 {
    font-family: 'Arial', sans-serif;
    font-size: 60px;
    color: #4CAF50;
    text-transform: uppercase;
    text-align: center;
    position: relative;
    display: inline-block;
    letter-spacing: 3px;
    background-image: linear-gradient(to right, #ff7e5f, #feb47b);
    -webkit-background-clip: text;
    background-clip: text;
    animation: colorChange 3s infinite alternate, slideIn 1s ease-out;
    transition: all 0.3s ease-in-out;
}

@keyframes colorChange {
    0% {
        color: #ff7e5f;
        transform: scale(1);
    }
    100% {
        color: rgb(48, 48, 48);
        transform: scale(1.1);
    }
}

@keyframes slideIn {
    0% {
        opacity: 0;
        transform: translateX(-100px);
    }
    100% {
        opacity: 1;
        transform: translateX(0);
    }
}

h1:hover {
    color: #fff;
    text-shadow: 4px 4px 10px rgb(255, 0, 0), -4px -4px 10px rgba(0, 0, 0, 0.4);
    transform: scale(1.1) rotate(-3deg);
}

h2 {
    font-size: 28px;
    text-align: center;
    color: rgb(0, 0, 0);
    text-transform: uppercase;
    position: relative;
    display: inline-block;
    letter-spacing: 2px;
    background-image: linear-gradient(to right, #ff7e5f, #feb47b);
    -webkit-background-clip: text;
    background-clip: text;
    animation: colorChange 3s infinite alternate, slideIn 1s ease-out;
    transition: all 0.3s ease-in-out;
}

@keyframes colorChange {
    0% {
        color: #ff7e5f;
        transform: scale(1);
    }
    100% {
        color: rgb(48, 48, 48);
        transform: scale(1.1);
    }
}

@keyframes slideIn {
    0% {
        opacity: 0;
        transform: translateY(-30px);
    }
    100% {
        opacity: 1;
        transform: translateY(0);
    }
}


h2:hover {
    color: #fff;
    text-shadow: 4px 4px 10px rgb(255, 0, 0), -4px -4px 10px rgba(0, 0, 0, 0.4);
    transform: scale(1.1) rotate(-3deg);
}



    </style>
</head>
<body>

    <div class="navbar">
        <div class="navbar-header">
            <img src="indir.png" alt="">
            <h1>Çiçek Buketi</h1>
        </div>
        <a href="panel.php"><i>🏠</i> Ana Sayfa</a>
    <a href="setting.php"><i>⚙️</i> Ayarlar</a>
    <a href="products.php"><i>🛒</i> Ürün Yönetimi</a>
    <a href="logout.php"><i>🚪</i> Çıkış Yap</a>
    </div>

    <div class="settings-container">
        <h2>SİTE Ayarları</h2>
        <form action="ayarlar.php" method="POST">
            <div class="form-group">
                <label for="ayar_baslik">Site Başlığı:</label>
                <input type="text" id="ayar_baslik" name="ayar_baslik" placeholder="Site başlığını girin" required>
            </div>
            <div class="form-group">
                <label for="site_description">Site Açıklaması:</label>
                <textarea id="site_description" name="site_description" placeholder="Site açıklamasını girin" required></textarea>
            </div>
            <div class="form-group">
                <label for="email">E-posta:</label>
                <input type="email" id="email" name="email" placeholder="E-posta adresini girin" required>
            </div>
            <div class="form-group">
                <label for="phone">Telefon:</label>
                <input type="text" id="phone" name="phone" placeholder="Telefon numarasını girin" required>
            </div>
            <button type="submit" class="btn">Kaydet</button>
        </form>
    </div>
    <div class="settings-container">
        <h2>Sosyal Medya Ayarları</h2>
        <form action="ayarlar.php" method="POST">
            <div class="form-group">
                <label for="site_title">Facebook:</label>
                <input type="text" id="site_title" name="site_title" placeholder="facebook adresini giriniz" required>
            </div>
            <div class="form-group">
                <label for="site_description">İnstagram:</label>
                <textarea id="site_description" name="site_description" placeholder="instagram adresini giriniz" required></textarea>
            </div>
            <div class="form-group">
                <label for="email">Twitter:</label>
                <input type="email" id="email" name="email" placeholder="twitter adresini giriniz" required>
            </div>

            <button type="submit" class="btn">Kaydet</button>
        </form>
    </div>
    <div class="footer">
     © 2025 Tüm Hakları Saklıdır|Çiçek Buketi 
    </div>

</body>
</html>
