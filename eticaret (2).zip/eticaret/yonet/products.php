
<?php
session_start();
if (!isset($_SESSION['loggedin'])) {
    header("Location: login.php");
    exit;
}
   
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ürünler Yönetimi</title>
    <style>
body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color: rgb(255, 255, 255);
    transition: background-color 0.5s ease; 
}

body:hover {
    background-color: rgb(0, 0, 0); 
}

.navbar {
    background-color: rgb(0, 0, 0);
    padding: 20px 40px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
}

.navbar-header img {
    width: 50px;
    height: auto;
}

.navbar h1 {
    margin-left: 15px;
    font-size: 28px;
    font-weight: 600;
    color: #fff;
    text-transform: uppercase;
}

.navbar a {
    color: #fff;
    text-decoration: none;
    font-size: 16px;
    transition: all 0.3s ease-in-out;
}

.navbar a:hover {
    color: rgb(243, 18, 18); 
    transform: translateY(-2px); 
    text-shadow: 50px 50px 10px rgb(46, 0, 0); 
}







.content:hover {
    background-color: rgb(0, 0, 0);
    box-shadow: 0 3px 15px rgb(255, 0, 0);
}

.dashboard {
    display: flex;
    flex-wrap: wrap;
    gap: 12px;
    justify-content: space-between;
    margin-bottom: 15px;
}


.dashboard:hover {
    background-color: #e0e0e0;
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);
}

.stat-box {
    background-color: #fff;
    padding: 12px;
    margin: 6px;
    border-radius: 6px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    transition: all 0.3s ease-in-out;
}


.stat-box:hover {
    background-color: #f0f0f0;
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);
    transform: translateY(-4px);
}

.table-container {
    background-color: #fff;
    padding: 15px;
    margin: 8px;
    border-radius: 6px;
    box-shadow: 0 3px 6px rgba(0, 0, 0, 0.1);
    transition: all 0.3s ease-in-out;
}

.table-container:hover {
    background-color: #e9e9e9;
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);
    transform: translateY(-4px);
}

table {
    width: 100%;
    border-collapse: collapse;
}

th, td {
    padding: 8px;
    text-align: left;
    border-bottom: 1px solid #ddd;
}

th {
    background-color: #f4f4f4;
}

td {
    background-color: #fff;
    color: #333;
}

tr:nth-child(even) {
    background-color: #f9f9f9;
}

tr:hover {
    background-color: #f1f1f1;
    transform: scale(1.01);
}

.footer {
    background-color: rgb(0, 0, 0);
    color: white;
    text-align: center;
    padding: 10px;
    position: relative;
    bottom: 0;
    width: 100%;
    font-size: 12px;
}

.footer a {
    color: #f39c12;
    text-decoration: none;
    transition: color 0.3s ease;
}

.footer a:hover {
    color: #f1c40f;
}

h1 {
    font-family: 'Arial', sans-serif;
    font-size: 48px;
    color: #4CAF50;
    text-transform: uppercase;
    text-align: center;
    position: relative;
    display: inline-block;
    letter-spacing: 2px;
    background-image: linear-gradient(to right, #ff7e5f, #feb47b);
    -webkit-background-clip: text;
    background-clip: text;
    animation: colorChange 3s infinite alternate, slideIn 1s ease-out;
    transition: all 0.3s ease-in-out;
}

@keyframes colorChange {
    0% {
        color: #ff7e5f;
        transform: scale(1);
    }
    100% {
        color: rgb(48, 48, 48);
        transform: scale(1.05);
    }
}

@keyframes slideIn {
    0% {
        opacity: 0;
        transform: translateX(-100px);
    }
    100% {
        opacity: 1;
        transform: translateX(0);
    }
}

h1:hover {
    color: #fff;
    text-shadow: 4px 4px 8px rgb(255, 0, 0), -4px -4px 8px rgba(0, 0, 0, 0.4);
    transform: scale(1.05) rotate(-3deg);
}

h2 {
    color: #333;
    text-align: center;
}
.product-form {
    background-color: #f9f9f9;
    padding: 15px;
    border-radius: 6px;
    box-shadow: 0 3px 6px rgba(0, 0, 0, 0.1); 
    margin-top: 20px;  
    margin-left: 400px; 
    margin-right: 400px; 
    margin-bottom: 15px;
    transition: box-shadow 0.3s ease, background-color 0.3s ease; 
}


.product-form:hover {
    background-color:rgb(0, 0, 0); 
    box-shadow: 0 6px 50px rgb(255, 0, 0);  
}






.product-form h3 {
    color: #333;
    margin-bottom: 8px;
    transition: color 0.3s ease; 
}


.product-form h3:hover {
    color: #ff7e5f; 
}






label {
    display: block;
    margin: 6px 0 3px;
    font-weight: bold;
}

input, select, textarea {
    width: 100%;
    padding: 8px;
    margin-bottom: 12px;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
}

input[type="file"] {
    padding: 4px;
}

button {
    width: 100%;
    padding: 8px;
    background-color: #28a745;
    color: #fff;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 14px;
    transition: background-color 0.3s ease;
}

button:hover {
    background-color: #218838;
}

.product-list {
    margin-top: 30px;
    padding: 15px;
    background-color: #f9f9f9; 
    border-radius: 6px;
    box-shadow: 0 3px 6px rgba(0, 0, 0, 0.1); 
    transition: box-shadow 0.3s ease-in-out, background-color 0.3s ease-in-out; 
    margin-left: 40px; 
    margin-right: 40px;
    margin-bottom: 40px;
}

.product-list:hover {
    background-color: #000; 
    color: #fff; 
    box-shadow: 0 6px 50px rgb(255, 0, 0); 
}


.product-list:hover {
    box-shadow: 0 6px 50px rgb(255, 0, 0); 
}

.product-list h3 {
    font-size: 24px;
    font-weight: bold;
    color: #333;
    margin-bottom: 10px;
}

.product-list p {
    font-size: 16px;
    color: #666;
    line-height: 1.6;
}

.product-list .product-item {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 10px;
    border-bottom: 1px solid #ddd;
}

.product-list .product-item:last-child {
    border-bottom: none; 
}

.product-list .product-item img {
    width: 50px;
    height: 50px;
    object-fit: cover;
    border-radius: 4px;
    margin-right: 10px;
}

.product-list .product-item .product-info {
    flex-grow: 1;
}

.product-list .product-item .product-name {
    font-size: 18px;
    font-weight: 600;
    color: #333;
}

.product-list .product-item .product-price {
    font-size: 16px;
    color: #28a745;
    font-weight: bold;
}

.product-list .product-item .product-actions button {
    padding: 6px 12px;
    font-size: 14px;
    background-color: #007bff;
    color: #fff;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

.product-list .product-item .product-actions button:hover {
    background-color: #0056b3;
}


table th, table td {
    padding: 10px;
    text-align: left;
    border: 1px solid #ddd;
}

table th {
    background-color: #f2f2f2;
    color: #333;
}

table tbody tr:nth-child(even) {
    background-color: #f9f9f9;
}

table tbody tr:hover {
    background-color: #f1f1f1;
}

table td img {
    max-width: 80px;
    height: auto;
    border-radius: 4px;
}

button.edit, button.delete {
    padding: 6px 12px; 
    font-size: 12px;  
    border-radius: 4px;  
    border: none; 
    cursor: pointer; 
    transition: all 0.3s ease; 
}

button.edit {
    background-color: #007bff;
    color: #fff;  
}

button.edit:hover {
    background-color: #0056b3;
    transform: scale(1.1);  
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);  
}

button.delete {
    background-color: #dc3545;
    color: #fff;  
}

button.delete:hover {
    background-color: #c82333;
    transform: scale(1.1); 
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);  
}

/* Tıklama (active) animasyonu */
button.edit:active, button.delete:active {
    animation: pressAnimation 0.2s ease-in-out;  
}

@keyframes pressAnimation {
    0% {
        transform: scale(1);
    }
    50% {
        transform: scale(0.95);  
    }
    100% {
        transform: scale(1);
    }
}

.h2-container {
    display: flex;
    justify-content: center;  
    align-items: center;    

}

@keyframes colorChange {
    0% {
        color: #ff7e5f;
        transform: scale(1);
    }
    100% {
        color: rgb(48, 48, 48);
        transform: scale(1.1);
    }
}

@keyframes slideIn {
    0% {
        opacity: 0;
        transform: translateY(-30px);
    }
    100% {
        opacity: 1;
        transform: translateY(0);
    }
}

/* Hover efekti */
h2:hover {
    color: #fff;
    text-shadow: 4px 4px 10px rgb(255, 0, 0), -4px -4px 10px rgba(0, 0, 0, 0.4);
    transform: scale(1.1) rotate(-3deg);
}

label[for="product-price"] {
    color:rgb(113, 113, 113);
}
label[for="product-stock"] {
    color:rgb(113, 113, 113);
}
label[for="product-name"] {
    color:rgb(113, 113, 113);
}
label[for="product-category"] {
    color:rgb(113, 113, 113);
}

label[for="product-category"] {
    color:rgb(113, 113, 113);
}
label[for="product-description"] {
    color:rgb(113, 113, 113);
}

label[for="product-image"] {
    color:rgb(113, 113, 113);
}

button[type="submit"] {
    font-size: 12px;             
    border-radius: 3px;           
    border: none;              
    background-color:rgb(0, 0, 0);   
    color: white;          
    cursor: pointer;             
    transition: all 0.3s ease;    
    width: 80px;                  
    text-align: center;          
    display: inline-block;  
    margin: 0 auto;             
    
    transform: scale(1);        
}


button[type="submit"]:hover {
    background-color:rgb(0, 0, 0);  
    transform: scale(1.1);        
    box-shadow: 0 4px 8px rgb(255, 0, 0); 
}


.action-btn {
    font-size: 12px;            
    border-radius: 3px;     
    border: none;                 
    background-color:rgb(0, 0, 0);   
    color: white;             
    cursor: pointer;             
    transition: all 0.3s ease;    
    width: 100px;             
    text-align: center;           
    display: inline-block;      
    margin: 10px;             
    padding: 6px 16px;          
    transform: scale(1);          
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    margin-left: 0px;  
}

.action-btn:hover {
    background-color:rgb(0, 0, 0);  
    transform: scale(1.1);       
    box-shadow: 0 4px 10px rgb(255, 0, 0); 
}

    </style>
</head>
<body>
<div class="navbar">
        <div class="navbar-header">
            <img src="indir.png" alt="">
            <h1>Çiçek Buketi</h1>
        </div>
        <a href="panel.php"><i>🏠</i> Ana Sayfa</a>
        <a href="setting.php"><i>⚙️</i> Ayarlar</a>
        <a href="products.php"><i>🛒</i> Ürün Yönetimi</a>
        <a href="logout.php"><i>🚪</i> Çıkış Yap</a>
    </div>
    <div class="container">
    <div class="h2-container">
    <h2>Ürünler Yönetimi</h2>
</div>


     
        <div class="product-form">
    <h3>Yeni Ürün Ekle</h3>
    <form method="POST" action="add_product.php" enctype="multipart/form-data">
        <label for="product-name">Ürün Adı:</label>
        <input type="text" id="product-name" name="product_name" required>

        <label for="product-price">Fiyat:</label>
        <input type="number" id="product-price" name="product_price" step="0.01" required>

        <label for="product-stock">Stok Adedi:</label>
        <input type="number" id="product-stock" name="product_stock" required>

        <label for="product-category">Kategori:</label>
        <select id="product-category" name="product_category">
            <option value="Ana Sayfa">Ana Sayfa</option>
            <option value="Ürünler">Ürünler</option>
        </select>

        <label for="product-description">Açıklama:</label>
        <textarea id="product-description" name="product_description" rows="4"></textarea>


        <label for="product-image">Ürün Fotoğrafı:</label>
        <input type="file" id="product-image" name="product_image" accept="image/*">


        <button type="submit">Ekle</button>
    </form>
</div>



        <div class="product-list">
            <h2>Mevcut Ürünler</h2>
            <table>
                <thead>
                    <tr>
                        <th>Ürün Adı</th>
                        <th>Fiyat</th>
                        <th>Stok</th>
                        <th>Kategori</th>
                        <th>Açıklama</th>
                        <th>Fotoğraf</th> 
                        <th>İşlemler</th>
                    </tr>
                </thead>
                <tbody>
    
                    <?php
          
            $conn = new mysqli('localhost', 'root', '', 'eticaret1');
            if ($conn->connect_error) {
                die("Bağlantı hatası: " . $conn->connect_error);
            }
            $result = $conn->query("SELECT * FROM products");

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
            
                    $image_path = 'uploads/' . $row['image'];
                    echo "<tr>
                        <td>{$row['name']}</td>
                        <td>{$row['price']}</td>
                        <td>{$row['stock']}</td>
                        <td>{$row['category']}</td>
                        <td>{$row['description']}</td>
                        <td>";
             
                        if (!empty($row['image']) && file_exists($image_path)) {
                            echo "<img src='{$image_path}' alt='Ürün Fotoğrafı' style='width: 100px; height: 100px; object-fit: cover;'>";
                        } else {
                            echo "Fotoğraf yok";
                        }
                    echo "</td>
                        <td>
                            <button class='action-btn'>Düzenle</button>
                            <button class='action-btn'>Güncelle</button>
                            <form method='POST' action=''>
                                        <input type='hidden' name='product_id' value='{$row['id']}'>
                                        <button type='submit' name='delete' class='action-btn'>Sil</button>
                                    </form>
                        </td>
                    </tr>";
                }
            } else {
                echo "<tr><td colspan='7' style='text-align: center;'>Henüz ürün eklenmedi.</td></tr>";
            }

            $conn->close();
            ?>
                </tbody>
            </table>
        </div>

      
        <?php
        if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete'])) {
            $product_id = $_POST['product_id'];

        
            $conn = new mysqli('localhost', 'root', '', 'natural_stones');
            if ($conn->connect_error) {
                die("Bağlantı hatası: " . $conn->connect_error);
            }

     
            $delete_query = "DELETE FROM products WHERE id = ?";
            $stmt = $conn->prepare($delete_query);
            $stmt->bind_param('i', $product_id);
            $stmt->execute();

       
            if ($stmt->affected_rows > 0) {
                echo "<script>alert('Ürün başarıyla silindi.'); window.location.href = window.location.href;</script>";
            } else {
                echo "<script>alert('Bir hata oluştu. Ürün silinemedi.');</script>";
            }

            $stmt->close();
            $conn->close();
        }
?>

    </div>
    </div>
    <div class="footer">
     © 2025 Tüm Hakları Saklıdır|Çiçek Buketi 
    </div>
</body>
</html>