<?php 
include "Ust.php";
?>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "eticaret1";

$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Bağlantı hatası: " . $conn->connect_error);
}

$sql = "SELECT * FROM urun";
$result = $conn->query($sql);




if (isset($_POST['add_to_cart'])) {
    $product_id = $_POST['id'];
    $quantity = 1;
    $_SESSION['cart'][] = ['id' => $product_id, 'quantity' => $quantity];
}
?>
    <section class="product-filter-section">
	<div class="container">
		<div class="section-title">
			<h2>ÜRÜNLERİMİZ</h2>
		</div>
		<div class="row">
			<?php 
			$Urunler=$db->query("SELECT * FROM products ");

			while($Urun=$Urunler->fetch())
			{
				?>
				<div class="col-lg-3 col-sm-6">
					<?php UrunListeGorunumu($Urun) ?>
				</div>
				<?php 
			}
        
    
            ?>
   		</div>
	
	</div>
</section>


<?php 
include "Alt.php";
?>




