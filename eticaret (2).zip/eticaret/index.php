<?php 
include"Ust.php";
?>

<section class="hero-section">

					
</section>





<section class="features-section">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-4 p-0 feature">
			<div class="feature-inner">
    <div class="feature-icon">
        <img src="shipping (2).png" alt="#" class="shipping-icon">
    </div>
    <h2>HIZLI KARGO</h2>
</div>

			</div>
			<div class="col-md-4 p-0 feature">
				<div class="feature-inner">
					<div class="feature-icon">
					<img src="paraiade (3).png" alt="#" class="small-image">

					</div>
					<h2>PARA İADE GARANTİSİ</h2>
				</div>
			</div>
			<div class="col-md-4 p-0 feature">
				<div class="feature-inner">
					<div class="feature-icon">
					<img src="güvenlik.png" alt="#" style="width: 50px; height: auto;">

					</div>
					<h2>GÜVENLİ ALIŞVERİŞ</h2>
				</div>
			</div>
		</div>
	</div>
</section>




<section class="top-letest-product-section">
	<div class="container">
		<div class="section-title">
			<h2>Yeni Ürünler</h2>
		</div>
		<div class="product-slider owl-carousel">
			<?php 
			$Urunler=$db->query("SELECT * FROM urun ORDER BY urun_id DESC LIMIT 5");

			while($Urun=$Urunler->fetch())
				UrunListeGorunumu($Urun);
			?>
		</div>
	</div>
</section>





<section class="product-filter-section">
	<div class="container">
		<div class="section-title">
			<h2>Öne Çıkan Ürünler</h2>
		</div>
		<div class="row">
			<?php 
			$Urunler=$db->query("SELECT * FROM urun WHERE urun_vitrin=1 ORDER BY RAND() LIMIT 8");

			while($Urun=$Urunler->fetch())
			{
				?>
				<div class="col-lg-3 col-sm-6">
					<?php UrunListeGorunumu($Urun) ?>
				</div>
				<?php 
			}
			?>
		</div>
	
	</div>
</section>




<section class="banner-section">




<?php 
include"Alt.php";

?>




