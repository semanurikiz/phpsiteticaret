<?php
session_start();
$message = "";
include('db_connection.php');


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];


    $hashed_password = password_hash($password, PASSWORD_BCRYPT);


    $sql = "SELECT * FROM users WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $message = "Bu kullanıcı adı zaten alınmış.";
    } else {
     
        $sql = "INSERT INTO users (username, password) VALUES (?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $username, $hashed_password);
        $stmt->execute();

        $message = "Kayıt başarılı! Şimdi giriş yapabilirsiniz.";
    }

    $stmt->close();
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kayıt Ol</title>
    <link rel="stylesheet" href="style.css">
	<link href="gul.png" rel="shortcut icon"/>

  <style>

body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color: rgb(30, 30, 30);
    transition: background-color 0.5s ease;
}

body:hover {
    background-color: rgb(0, 0, 0);
}

.register-container {
    width: 100%;
    max-width: 400px;
    margin: 100px auto;
    padding: 30px;
    background-color: white;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgb(68, 42, 36);
    text-align: center;
    transition: box-shadow 0.3s ease; 
}

.register-container:hover {
    box-shadow: 0 10px 100px rgb(255, 0, 0);
}

h1 {
    margin-bottom: 20px;
    color: #333;
}

form {
    display: flex;
    flex-direction: column;
    gap: 15px;
}

label {
    text-align: left;
    font-weight: bold;
}

input {
    padding: 10px;
    font-size: 16px;
    border: 1px solid #ccc;
    border-radius: 5px;
}

button {
    background-color: rgb(105, 0, 0);
    color: white;
    padding: 15px;
    border: none;
    border-radius: 5px;
    font-size: 16px;
    cursor: pointer;
    transition: box-shadow 0.3s ease; 
}

button:hover {
    background-color: rgb(105, 0, 0);
    box-shadow: 0 10px 12px rgb(103, 0, 0); 
}

p {
    margin-top: 20px;
}

.message {
    color: #7a4fba;
    margin-bottom: 20px;
}

  </style>
</head>
<body>

<div class="register-container">
    <h1>Kayıt Ol</h1>

  
    <?php if ($message): ?>
        <p class="message"><?php echo $message; ?></p>
    <?php endif; ?>

    <form method="POST" action="">
        <label for="username">Kullanıcı Adı:</label>
        <input type="text" id="username" name="username" required>

        <label for="password">Şifre:</label>
        <input type="password" id="password" name="password" required>

        <button type="submit">Kayıt Ol</button>
    </form>

    <p>Zaten hesabınız var mı? <a href="login.php">Giriş Yap</a></p>
</div>

</body>
</html>



